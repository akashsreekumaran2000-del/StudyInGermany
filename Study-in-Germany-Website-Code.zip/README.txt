STUDY IN GERMANY — WEBSITE SOURCE

Includes all six HTML pages, style.css, app.js, and assets (photos and original logos).
No npm install or build step is required.

PREVIEW
Extract the ZIP. Open a terminal in the extracted website folder and run:
  python -m http.server 8000
Then open http://localhost:8000 in your browser.
Use a local web server rather than double-clicking index.html: the original site uses root-relative links.

HOSTING
Upload the contents of this folder to the document root of any static web host.
Keep the page folders and assets folder intact. Serve index.html as each directory's default page.
For hosting under a subdirectory, adjust root-relative links to include that subdirectory.

EDITING
index.html: Home
about/index.html: About & FAQs
applicants/index.html: Applicants
companies/index.html: Companies
training-opportunities/index.html: Opportunities
contact/index.html: Contact
style.css: Shared styling and responsive layout
app.js: Navigation, pathway search/filters and WhatsApp enquiry handling
assets/: Included photos and logos

CONTACT & REGISTRATION
Call buttons use +91 7012326297 and +91 9605069940.
WhatsApp buttons open prefilled messages. The visitor presses Send in WhatsApp.
Registration buttons link to the supplied Google Form.
The site does not store form submissions or upload files itself.
Google Fonts, WhatsApp and Google Forms require internet access.

ASSET SOURCES
Logos: supplied by Travel Trails.
Photos: Unsplash image URLs used by the reference site:
https://images.unsplash.com/photo-1521737711867-e3b97375f902
https://images.unsplash.com/photo-1523240795612-9a054b0db644
https://images.unsplash.com/photo-1581092160562-40aa08e78837
